#ifndef __BOARD_MPC837XEMDS_PCI_H
#define __BOARD_MPC837XEMDS_PCI_H

extern void ft_pcie_fixup(void *blob, bd_t *bd);

#endif /* __BOARD_MPC837XEMDS_PCI_H */
